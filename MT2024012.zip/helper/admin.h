#include <stdio.h>      /* printf(), perror() */
#include <stdlib.h>     /*  */
#include <unistd.h>     /* fork(), close(), read(), _exit() */
#include <string.h>     /* strncpy() */
#include <arpa/inet.h>  /* htons() */
#include <sys/socket.h> /* send(), recv() */
#include <netinet/in.h>
#include <fcntl.h>
#include <sys/file.h>

#define ADMIN_MENU "\nAdministrator Menu:\n1. Add New Bank Employee\n2. Show Employees\n3. Modify Customer Details\n4. Modify Employee/Customer Username\n5. Manage Roles\n6. Change Password\n7. Logout\nEnter your choice: "

void addUser(enum Role userRole);
void adminlogin(struct user *loginUser, int connectionFileDescriptor);
void show_employees();
int authenticate(struct user *loginUser);
unsigned long hash_password(const char *password);
void logout(struct user *loginUser);
void change_password(struct user *loginUser, int connectionFileDescriptor);
void modify_customer(int connectionFileDescriptor);
int change_status(int user_id, int new_status);
void modify_username(int connectionFileDescriptor);
int change_username(int user_id, char *new_username);
void manage_roles(int connectionFileDescriptor);

char serverMessagea[1000], clientMessagea[1000], dummyBuffera[100];

void clearBuffers()
{
    bzero(serverMessagea, sizeof(serverMessagea));
    bzero(clientMessagea, sizeof(clientMessagea));
    bzero(dummyBuffera, sizeof(dummyBuffera));
}

void fillDummy()
{
    strcpy(dummyBuffera, "This is a Dummy Message\n");
}

void change_password(struct user *loginUser, int connectionFileDescriptor)
{
    int fd = open(USER_DB, O_RDWR);
    if (fd < 0)
    {
        perror("Error opening USER_DB");
        return;
    }

    char username[50];
    char new_password[50];
    strcpy(username, loginUser->username);
    off_t offset;
    struct user find_User;
    struct flock lock;

    // printf("Enter the new password : ");
    // scanf("%s", new_password);

    strcpy(serverMessagea, "Enter the new password : ");
    send(connectionFileDescriptor, serverMessagea, strlen(serverMessagea), 0);
    recv(connectionFileDescriptor, clientMessagea, sizeof(clientMessagea), 0);
    strcpy(new_password, clientMessagea);
    clearBuffers();

    ssize_t read_status;
    while ((read_status = read(fd, &find_User, sizeof(struct user))) == sizeof(struct user))
    {
        if (strcmp(username, find_User.username) == 0 && loginUser->role == find_User.role)
        {
            loginUser->hashed_password = hash_password(new_password);
            loginUser->session = find_User.session;
            loginUser->status = find_User.status;
            loginUser->user_id = find_User.user_id;
            offset = lseek(fd, -1 * sizeof(struct user), SEEK_CUR);
            break;
        }
    }

    if (read_status == -1)
    {
        perror("Error reading USER_DB");
        close(fd);
        return;
    }

    if (offset != -1)
    {
        lock.l_type = F_WRLCK;
        lock.l_whence = SEEK_SET;
        lock.l_start = offset;
        lock.l_len = sizeof(struct user);
        lock.l_pid = getpid();

        fcntl(fd, F_SETLK, &lock);

        lseek(fd, offset, SEEK_SET);

        int write_status = write(fd, loginUser, sizeof(struct user));
        if (write_status == sizeof(struct user))
        {
            strcpy(serverMessagea, "Password Change Successful\n");
            send(connectionFileDescriptor, serverMessagea, strlen(serverMessagea), 0);
        }
        else
        {
            perror("Error While Changing Password");
            strcpy(serverMessagea, "Error While Changing Password\n");
            send(connectionFileDescriptor, serverMessagea, strlen(serverMessagea), 0);
        }
        lock.l_type = F_UNLCK;
        fcntl(fd, F_SETLK, &lock);
    }
    else
    {
        // printf("User not found.\n");
        strcpy(serverMessagea, "User not found.\n");
        send(connectionFileDescriptor, serverMessagea, strlen(serverMessagea), 0);
    }

    recv(connectionFileDescriptor, dummyBuffera, sizeof(dummyBuffera));
    clearBuffers();

    close(fd);
}

void logout(struct user *loginUser)
{
    struct user fileUser;
    int fd, write_bytes;
    fd = open(USER_DB, O_RDWR);
    if (fd == -1)
    {
        perror("Error opening user database");
        return;
    }

    lseek(fd, 0, SEEK_SET);

    while (read(fd, &fileUser, sizeof(struct user)) > 0)
    {
        if (
            strcmp(loginUser->username, fileUser.username) == 0 &&
            loginUser->hashed_password == fileUser.hashed_password &&
            loginUser->role == fileUser.role)
        {

            fileUser.session = 1;
            lseek(fd, -1 * sizeof(struct user), SEEK_CUR);
            write_bytes = write(fd, &fileUser, sizeof(struct user));
            if (write_bytes < 0)
            {
                perror("Error updating user status");
            }
            else
            {
                break;
            }
        }
    }
    close(fd);
}

void show_employees(int connectionFileDescriptor)
{
    int fd = open(USER_DB, O_RDONLY);
    struct user employeeUser;
    strcpy(serverMessagea, "Employees\n");
    strcat(serverMessagea, "Employee ID\tEmployee Username\n");
    while (read(fd, &employeeUser, sizeof(struct user)) > 0)
    {
        if (employeeUser.role == EMPLOYEE)
        {
            char str[20];
            snprintf(str, sizeof(str), "%d", employeeUser.user_id);
            strcat(serverMessagea, str);
            strcat(serverMessagea, " ");
            strcat(serverMessagea, employeeUser.username);
            strcat(serverMessagea, "\n");
        }
    }
    send(connectionFileDescriptor, serverMessagea, strlen(serverMessagea));
    printf("%s", serverMessagea);
    recv(connectionFileDescriptor, dummyBuffera, sizeof(dummyBuffera));
    clearBuffers()
}

void adminlogin(struct user *loginUser, int connectionFileDescriptor)
{
    char password[50];
    enum Role userRole2 = ADMIN;
    int choice;

    strcat(serverMessagea, "Enter username: ");
    send(connectionFileDescriptor, serverMessagea, strlen(serverMessagea), 0);
    recv(connectionFileDescriptor, clientMessagea, sizeof(clientMessagea), 0);
    strcpy(loginUser->username, clientMessagea);
    clearBuffers();

    strcat(serverMessagea, "Enter password: ");
    send(connectionFileDescriptor, serverMessagea, strlen(serverMessagea), 0);
    recv(connectionFileDescriptor, clientMessagea, sizeof(clientMessagea), 0);
    loginUser->hashed_password = hash_password(clientMessagea);
    clearBuffers();

    int status = authenticate(loginUser);
    snprintf(serverMessagea, sizeof(serverMessagea), "%d", choice);
    send(connectionFileDescriptor, serverMessagea, strlen(serverMessagea), 0);
    recv(connectionFileDescriptor, dummyBuffera, sizeof(dummyBuffera), 0);
    clearBuffers();
    loginUser->role = userRole2;

    if (status == 1)
    {
        while (1)
        {
            strcpy(serverMessage, ADMIN_MENU);
            send(connectionFileDescriptor, serverMessagea, strlen(serverMessagea), 0);
            recv(connectionFileDescriptor, clientMessagea, sizeof(clientMessagea), 0);
            int menu_choice = atoi(clientMessagea);
            clearBuffers();

            switch (menu_choice)
            {
            case 1:
                enum Role userRole1 = EMPLOYEE;
                addUser(userRole1);
                break;
            case 2:
                show_employees(connectionFileDescriptor);
                break;
            case 3:
                modify_customer(connectionFileDescriptor);
                break;
            case 4:
                modify_username(connectionFileDescriptor);
                break;
            case 5:
                manage_roles(connectionFileDescriptor);
                break;
            case 6:
                change_password(loginUser, connectionFileDescriptor);
                break;
            case 7:
                logout(loginUser);
                send(connectionFileDescriptor, "Logging Out ...", strlen("Logging Out ..."));
                recv(connectionFileDescriptor, dummyBuffera, sizeof(dummyBuffera));
                clearBuffers();
                return;
            default:
                send(connectionFileDescriptor, "Invalid choice!\n", strlen("Invalid choice!\n"), 0);
                recv(connectionFileDescriptor, dummyBuffera, sizeof(dummyBuffera), 0);
                clearBuffers();
            }
        }
    }
    else
    {
        send(connectionFileDescriptor, "Invalid credentials!\n", strlen("Invalid credentials!\n"), 0);
        recv(connectionFileDescriptor, dummyBuffera, sizeof(dummyBuffera), 0);
        clearBuffers();
    }
}

int authenticate(struct user *loginUser)
{
    struct user fileUser;
    int fd, write_bytes;

    fd = open(USER_DB, O_RDWR);
    if (fd == -1)
    {
        perror("Error opening user database");
        return 0;
    }

    lseek(fd, 0, SEEK_SET);

    while (read(fd, &fileUser, sizeof(struct user)) > 0)
    {
        if (
            strcmp(loginUser->username, fileUser.username) == 0 &&
            loginUser->hashed_password == fileUser.hashed_password &&
            loginUser->role == fileUser.role)
        {
            if (fileUser.session == 1 && fileUser.status == 0)
            {
                fileUser.session = 0;
                lseek(fd, -1 * sizeof(struct user), SEEK_CUR);
                write_bytes = write(fd, &fileUser, sizeof(struct user));
                if (write_bytes == -1)
                {
                    perror("Error updating user status");
                    close(fd);
                    return 0;
                }

                close(fd);
                return 1;
            }
            else
            {
                close(fd);
                return 0;
            }
        }
    }
    close(fd);
    return 0;
}

unsigned long hash_password(const char *password)
{
    unsigned long hash = 5381;
    int c;

    while ((c = *password++))
    {
        hash = ((hash << 5) + hash) + c; // hash * 33 + c
    }

    return hash;
}

void addUser(enum Role userRole, int connectionFileDescriptor)
{
    struct user newUser;
    char username[50];
    char password[50];

    printf("Enter username: ");
    scanf("%s", username);
    strcpy(newUser.username, username);

    printf("Enter password: ");
    scanf("%s", password);
    newUser.user_id = generate_user_id();
    newUser.hashed_password = hash_password(password);
    newUser.role = userRole;
    newUser.status = 0;  // ACTIVE
    newUser.session = 1; // INACTIVE

    int user_fd = open(USER_DB, O_WRONLY | O_APPEND | O_CREAT, 0666);
    if (user_fd < 0)
    {
        perror("Error opening user database");
        exit(1);
    }

    if (write(user_fd, &newUser, sizeof(struct user)) < 0)
    {
        perror("Error writing to user database");
        close(user_fd);
        exit(1);
    }

    if (userRole == CUSTOMER)
    {
        int account_fd = open(ACCOUNT_DB, O_WRONLY | O_APPEND | O_CREAT, 0666);
        struct account newAccount;
        strcpy(newAccount.username, username);
        newAccount.balance = 0;
        if (write(account_fd, &newAccount, sizeof(struct account)) < 0)
        {
            perror("Error writing to account database");
            close(account_fd);
            exit(1);
        }
        close(account_fd);
    }
    strcpy(serverMessagea, "User added successfully!\n", sizeof("User added successfully!\n"));
    send(connectionFileDescriptor, serverMessagea, strlen(serverMessagea));
    recv(connectionFileDescriptor, clientMessagea, sizeof(clientMessagea));
    clearBuffers();
    close(user_fd);
}

void modify_customer(int connectionFileDescriptor)
{
    int user_id, new_status;

    strcpy(serverMessagea, "Enter the User ID: ");
    send(connectionFileDescriptor, serverMessagea, strlen(serverMessagea), 0);
    recv(connectionFileDescriptor, clientMessagea, sizeof(clientMessagea), 0);
    user_id = atoi(clientMessagea);
    clearBuffers();

    strcpy(serverMessagea, "Enter the New Status(0:Activate 1:Deactivate): ");
    send(connectionFileDescriptor, serverMessagea, strlen(serverMessagea), 0);
    recv(connectionFileDescriptor, clientMessagea, sizeof(clientMessagea), 0);
    new_status = atoi(clientMessagea);
    clearBuffers();

    int status = change_status(user_id, new_status);
    if (status == 1)
    {
        strcpy(serverMessagea, "Status Changed Successfully!\n");
        send(connectionFileDescriptor, serverMessagea, strlen(serverMessagea));
    }
    else if (status == 0)
    {
        strcpy(serverMessagea, "Status Not Updated!\n");
        send(connectionFileDescriptor, serverMessagea, strlen(serverMessagea));
    }
    else if (status == 2)
    {
        sprintf(serverMessagea, "User with user ID %d Not Found", user_id);
        send(connectionFileDescriptor, serverMessagea, strlen(serverMessagea));
    }
    recv(connectionFileDescriptor, dummyBuffera, sizeof(dummyBuffera));
    clearBuffers();
}

int change_status(int user_id, int new_status)
{
    int fd = open(USER_DB, O_RDWR);
    int ret = 0;
    if (fd < 0)
    {
        perror("Error opening USER_DB");
        exit(0);
    }

    struct user find_User;
    struct flock lock;
    off_t offset = -1;

    while (read(fd, &find_User, sizeof(struct user)) > 0)
    {
        if (find_User.user_id == user_id)
        {
            find_User.status = new_status;
            offset = lseek(fd, -1 * sizeof(struct user), SEEK_CUR);
            break;
        }
        else
        {
            ret = 2;
        }
    }

    if (offset != -1)
    {
        lock.l_type = F_WRLCK;
        lock.l_whence = SEEK_SET;
        lock.l_start = offset;
        lock.l_len = sizeof(struct user);
        lock.l_pid = getpid();
        fcntl(fd, F_SETLK, &lock);

        lseek(fd, offset, SEEK_SET);
        ssize_t write_status = write(fd, &find_User, sizeof(struct user));
        if (write_status > 0)
        {
            ret = 1;
        }
        else
        {
            ret = 0;
        }

        lock.l_type = F_UNLCK;
        fcntl(fd, F_SETLK, &lock);
    }
    close(fd);

    return ret;
}

void modify_username(int connectionFileDescriptor)
{
    int user_id;
    char new_username[50];

    printf("Enter the New Username ");
    scanf("%s", new_username);

    strcpy(serverMessagea, "Enter the User ID: ");
    send(connectionFileDescriptor, serverMessagea, strlen(serverMessagea), 0);
    recv(connectionFileDescriptor, clientMessagea, sizeof(clientMessagea), 0);
    user_id = atoi(clientMessagea);
    clearBuffers();

    strcpy(serverMessagea, "Enter the New Username ");
    send(connectionFileDescriptor, serverMessagea, strlen(serverMessagea), 0);
    recv(connectionFileDescriptor, clientMessagea, sizeof(clientMessagea), 0);
    strcpy(new_username, clientMessagea);
    clearBuffers();

    int status = change_username(user_id, new_username);
    if (status == 1)
    {
        strcpy(serverMessagea, "Username Changed Successfully!\n");
        send(connectionFileDescriptor, serverMessagea, strlen(serverMessagea));
    }
    else if (status == 0)
    {
        strcpy(serverMessagea, "Username Not Updated!\n");
        send(connectionFileDescriptor, serverMessagea, strlen(serverMessagea));
    }
    else if (status == 2)
    {
        sprintf(serverMessagea, "User with user ID %d Not Found", user_id);
        send(connectionFileDescriptor, serverMessagea, strlen(serverMessagea));
    }
    recv(connectionFileDescriptor, dummyBuffera, sizeof(dummyBuffera));
    clearBuffers();
}

int change_username(int user_id, char *new_username)
{
    int fd = open(USER_DB, O_RDWR);
    int ret = 2;
    if (fd < 0)
    {
        perror("Error opening USER_DB");
        exit(0);
    }

    struct user find_User;
    struct flock lock;
    off_t offset = -1;

    while (read(fd, &find_User, sizeof(struct user)) > 0)
    {
        if (find_User.user_id == user_id)
        {
            strcpy(find_User.username, new_username);
            offset = lseek(fd, -1 * sizeof(struct user), SEEK_CUR);
            ret = 2;
            break;
        }
    }

    if (offset != -1)
    {
        lock.l_type = F_WRLCK;
        lock.l_whence = SEEK_SET;
        lock.l_start = offset;
        lock.l_len = sizeof(struct user);
        lock.l_pid = getpid();
        fcntl(fd, F_SETLK, &lock);

        lseek(fd, offset, SEEK_SET);
        ssize_t write_status = write(fd, &find_User, sizeof(struct user));
        if (write_status == sizeof(struct user))
        {
            ret = 1;
        }
        else
        {
            ret = 0;
        }

        lock.l_type = F_UNLCK;
        fcntl(fd, F_SETLK, &lock);
    }
    close(fd);
    return ret;
}

void manage_roles()
{
    int user_id;
    int fd = open(USER_DB, O_RDWR);

    strcpy(serverMessagea, "Enter the User ID: ");
    send(connectionFileDescriptor, serverMessagea, strlen(serverMessagea), 0);
    recv(connectionFileDescriptor, clientMessagea, sizeof(clientMessagea), 0);
    user_id = atoi(clientMessagea);
    clearBuffers();

    struct user find_User;
    struct flock lock;
    off_t offset = -1;

    while (read(fd, &find_User, sizeof(struct user)) > 0)
    {
        if (find_User.user_id == user_id)
        {
            find_User.role = MANAGER;
            offset = lseek(fd, -1 * sizeof(struct user), SEEK_CUR);
            break;
        }
    }

    if (offset != -1)
    {
        lock.l_type = F_WRLCK;
        lock.l_whence = SEEK_SET;
        lock.l_start = offset;
        lock.l_len = sizeof(struct user);
        lock.l_pid = getpid();
        fcntl(fd, F_SETLK, &lock);

        lseek(fd, offset, SEEK_SET);
        ssize_t write_status = write(fd, &find_User, sizeof(struct user));
        if (write_status == sizeof(struct user))
        {
            snprintf(serverMessagea, "Employee %s Role Changed to Manager!\n", find_User.username);
            send(connectionFileDescriptor, serverMessagea, strlen(serverMessagea), 0);
        }
        else
        {
            strcpy(serverMessagea, "Employee Role Change Unsuccessfull\n");
            send(connectionFileDescriptor, serverMessagea, strlen(serverMessagea), 0);
        }

        lock.l_type = F_UNLCK;
        fcntl(fd, F_SETLK, &lock);
    }
    else
    {
        snprintf(serverMessagea, "Employee with User ID : %d Not Found\n", user_id);
        send(connectionFileDescriptor, serverMessagea, strlen(serverMessagea), 0);
    }
    recv(connectionFileDescriptor, dummyBuffera, sizeof(dummyBuffera));
    clearBuffers();
    close(fd);
}
