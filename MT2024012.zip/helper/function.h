#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <unistd.h>
#include <fcntl.h>

#include "structure.h"

int initiate_user_id()
{
    int fd = open(ID_FILE, O_RDWR | O_CREAT, 0644);
    char ID[100];
    strcpy(ID, "1000");
    write(fd, ID, sizeof(ID));
    close(fd);
}

int generate_user_id()
{

    int fd = open(ID_FILE, O_RDWR, 0644);
    int gen_id;
    char ID[100];

    struct flock lock;
    lock.l_type = F_WRLCK;
    lock.l_whence = SEEK_SET;
    lock.l_start = 0;
    lock.l_len = 0;
    lock.l_pid = getpid();

    fcntl(fd, F_SETLK, &lock);
    read(fd, ID, sizeof(ID));
    gen_id = atoi(ID);
    gen_id += 1;
    bzero(ID, sizeof(ID));
    snprintf(ID, sizeof(ID), "%d", gen_id);
    lseek(fd, 0, SEEK_SET);
    write(fd, ID, sizeof(ID));
    lock.l_type = F_UNLCK;
    fcntl(fd, F_SETLK, &lock);

    return gen_id;
}
